package uk.ac.ed.bikerental;

public interface Deliverable {
    void onPickup();

    void onDropoff();
}
